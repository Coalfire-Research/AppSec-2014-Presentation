#!/bin/sh

#
# This application is part of the clusterd attack framework.
# 
# This file builds the railopass encryption/decryption app
#
javac -cp . RailoPasswordTool.java
