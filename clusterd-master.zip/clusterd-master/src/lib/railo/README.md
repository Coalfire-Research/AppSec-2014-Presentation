Railo
====

This document details the Railo-specific resources necessary for various modules.

header.png  
  -- Default image used for a deployer 
railopass/
  -- Small app used to decrypt Railo passwords
