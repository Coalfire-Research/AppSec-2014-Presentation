coldfusion
=========

fuze.cfml - Fuze CF shell version 1.2; full featured backdoor (default creds: god|default)
