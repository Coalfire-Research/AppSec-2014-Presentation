Resources
======

This folder contains various shells or utilities that can be used for deployment.
Most of these were custom written to be small but still usable in a pinch.

+ cmd.cfml
  -- This is a very straight-forward coldfusion web shell, for when you don't
  want to or can't use fuze (railo)
+ cmd.jsp
  -- Simple JSP web shell that can be used on jboss, tomcat, or coldfusion 
+ cmd.war
  -- This is cmd.jsp packaged as a war file
